class Player:
    def __init__(self, name):
        self.name = name
        self.score = 0
        self.balls_faced = 0
        self.fours = 0
        self.sixes = 0