class Team:
    def __init__(self, name, players):
        self.name = name
        self.players = players
        self.total_score = 0
        self.wickets = 0