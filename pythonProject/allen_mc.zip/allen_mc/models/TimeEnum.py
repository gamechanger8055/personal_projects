from enum import Enum

class TimeEnum(Enum):
    Morning = 0
    Noon = 1
    Evening = 2

