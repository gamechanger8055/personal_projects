class Admin:
    def __init__(self,name, gender, role):
        self.name=name
        self.gender=gender
        self.role=role